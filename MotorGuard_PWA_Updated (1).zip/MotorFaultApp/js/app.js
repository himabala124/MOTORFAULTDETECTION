const DATA_URL = "http://192.168.50.203/vibration";

async function updateDashboard() {
  try {
    const response = await fetch(DATA_URL);
    const vibration = parseFloat(await response.text());

    const status = vibration > 10 ? "FAULT" : "NORMAL";
    const time = new Date().toLocaleTimeString();

    document.getElementById("faultStatus").textContent = status;
    document.getElementById("vibrationValue").textContent = vibration.toFixed(2);
    document.getElementById("lastUpdated").textContent = time;

    document.getElementById("motorStatus").textContent = status === "FAULT" ? "⚠️ Fault Detected" : "✅ Running Smoothly";
    document.getElementById("sensorStatus").textContent = "Active";

    if (status === "FAULT") {
      localStorage.setItem("lastFaultTime", time);
      let total = parseInt(localStorage.getItem("totalFaults") || 0);
      total += 1;
      localStorage.setItem("totalFaults", total);
    }

    // Update from localStorage
    const lastFault = localStorage.getItem("lastFaultTime") || "--";
    const totalFaults = localStorage.getItem("totalFaults") || "--";
    document.getElementById("lastFault").textContent = lastFault;
    document.getElementById("totalFaults").textContent = totalFaults;

  } catch (error) {
    console.error("Dashboard fetch error:", error);
    document.getElementById("faultStatus").textContent = "Error";
    document.getElementById("vibrationValue").textContent = "--";
  }
}

setInterval(updateDashboard, 5000);
updateDashboard();
